import { useNavigate } from 'react-router-dom'

export default function LoginPage() {
  const navigate = useNavigate()

  return (
    <div className="page-wrap">
      <div className="page-container flex min-h-screen items-center justify-center">
        <div className="glass w-full max-w-md rounded-[2rem] p-8">
          <p className="text-xs uppercase tracking-[0.3em] text-white/40">GoodbyePills</p>
          <h1 className="mt-3 text-3xl font-semibold">Welcome back</h1>
          <p className="mt-2 text-white/65">Sign in to continue your emotional reset journey.</p>

          <div className="mt-8 space-y-4">
            <input type="email" placeholder="Email" className="w-full rounded-2xl border border-white/10 bg-black/20 px-4 py-3 text-white placeholder:text-white/30" />
            <input type="password" placeholder="Password" className="w-full rounded-2xl border border-white/10 bg-black/20 px-4 py-3 text-white placeholder:text-white/30" />
            <button onClick={() => navigate('/dashboard')} className="w-full rounded-2xl bg-white px-4 py-3 font-medium text-black hover:bg-white/90">
              Login
            </button>
          </div>
        </div>
      </div>
    </div>
  )
}
