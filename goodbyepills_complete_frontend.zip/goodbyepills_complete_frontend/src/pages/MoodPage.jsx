import { useState } from 'react'
import { ArrowRight } from 'lucide-react'
import { useNavigate } from 'react-router-dom'
import AppSidebar from '../components/layout/AppSidebar'
import AppHeader from '../components/layout/AppHeader'
import PageShell from '../components/shared/PageShell'
import MoodCard from '../components/mood/MoodCard'
import { moods } from '../data/moods'

export default function MoodPage() {
  const [selectedMood, setSelectedMood] = useState(moods[0].id)
  const navigate = useNavigate()

  return (
    <div className="page-wrap">
      <div className="page-container">
        <div className="grid gap-6 lg:grid-cols-[290px_1fr]">
          <AppSidebar />
          <main className="space-y-6">
            <AppHeader title="Mood Check-In" subtitle="Select how you feel right now to personalize the rest of the experience." />
            <PageShell
              title="Choose your current emotional state"
              description="This helps guide the breathing, release, reflection, and recommendation flow."
              action={
                <button onClick={() => navigate('/breathing')} className="rounded-2xl border border-white/15 bg-white/5 px-5 py-3 text-white hover:bg-white/10">
                  Continue <ArrowRight className="ml-2 inline h-4 w-4" />
                </button>
              }
            >
              <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-4">
                {moods.map((mood) => (
                  <MoodCard
                    key={mood.id}
                    mood={mood}
                    active={selectedMood === mood.id}
                    onClick={() => setSelectedMood(mood.id)}
                  />
                ))}
              </div>
            </PageShell>
          </main>
        </div>
      </div>
    </div>
  )
}
