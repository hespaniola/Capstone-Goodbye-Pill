import { useNavigate } from 'react-router-dom'
import AppSidebar from '../components/layout/AppSidebar'
import AppHeader from '../components/layout/AppHeader'
import PageShell from '../components/shared/PageShell'
import { moods } from '../data/moods'

export default function RecommendationsPage() {
  const navigate = useNavigate()
  const mood = moods[0]

  return (
    <div className="page-wrap">
      <div className="page-container">
        <div className="grid gap-6 lg:grid-cols-[290px_1fr]">
          <AppSidebar />
          <main className="space-y-6">
            <AppHeader title="Recommendations" subtitle="Supportive suggestions based on the selected mood." />
            <PageShell
              title="Your next best steps"
              description="Simple recommendations to keep the reset experience moving in a supportive direction."
              action={
                <button onClick={() => navigate('/dashboard')} className="rounded-2xl border border-white/15 bg-white/5 px-5 py-3 text-white hover:bg-white/10">
                  Back to dashboard
                </button>
              }
            >
              <div className="grid gap-4 md:grid-cols-2">
                <div className="glass-dark rounded-[1.5rem] p-6">
                  <h2 className="text-xl font-semibold text-white">Mood-based suggestion</h2>
                  <p className="mt-3 text-white/75">{mood.recommendation}</p>
                </div>
                <div className="glass-dark rounded-[1.5rem] p-6">
                  <h2 className="text-xl font-semibold text-white">Recommended next step</h2>
                  <p className="mt-3 text-white/75">Try the breathing page first, then return to the journal for a short reflection entry.</p>
                </div>
              </div>
            </PageShell>
          </main>
        </div>
      </div>
    </div>
  )
}
