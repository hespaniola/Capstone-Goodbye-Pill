# GoodbyePills Frontend

Frontend-only capstone project scaffold for GoodbyePills.com.

## Run locally

```bash
npm install
npm run dev
```

## Notes
- This is frontend only.
- Login and signup are demo UI flows.
- Data is mocked for presentation/demo purposes.
